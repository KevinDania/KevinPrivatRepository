﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMI_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("do with Imperial unit by pressing (y) or Metric unit by pressing (k)");
            while (true)
            {
                string d = Console.ReadLine();
                if (d == "y")
                {
                    Console.Write("Enter your height (inch): ");
                    double height = NumberCheck();
                    Console.Write("Enter your weight (lb): ");
                    double weight = NumberCheck();
                    CalculateBMIImperial(height, weight);
                }
                else if (d == "k")
                {
                    Console.Write("Enter your height (cm): ");
                    double height = NumberCheck();
                    Console.Write("Enter your weight (kg): ");
                    double weight = NumberCheck();
                    CalculateBMIMetric(height, weight);
                }
                Console.WriteLine("wrong input, do with Imperial unit by pressing (y) or Metric unit by pressing (k)");
            }
        }

        public static void Message(double myBMI)
        {
            Console.WriteLine("Your BMI is {0}", Math.Round(myBMI, 1));
            if (myBMI< 18.5)
            {
                Console.WriteLine("You are udnerweight. you should see your doctor");
            }
            else if (myBMI > 18.5 && 25 > myBMI)
            {
                Console.WriteLine("You are within the ideal weight range.");
            }
            else if (myBMI > 25)
            {
                Console.WriteLine("You are overweight. You should see your doctor.");
            }
            Console.ReadKey();
            Environment.Exit(0);
        }
        public static double NumberCheck()
        {
            double number;
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out number)) { return number; }
                else { Console.WriteLine("wrong input, takes only numerical value. "); }
            }
        }

        public static void CalculateBMIImperial(double h, double w)
        {
            double BMI = (w / (h * h)) * 703;
            Message(BMI);
        }
        
        public static void CalculateBMIMetric(double h, double w)
        {
            double BMI = (w / h / h) * 10000;
            Message(BMI);
        }
    }
}
