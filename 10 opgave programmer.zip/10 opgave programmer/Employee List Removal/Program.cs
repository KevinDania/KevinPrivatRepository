﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Employee_List_Removal
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> Employee = new List<string>();
            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\Kevin Bjørn\Dropbox\Datamatiker\Programmering\10 opgave programmer\Employee List Removal\NamesList.txt");
            foreach (string line in lines)
            {
                Employee.Add(line);
            }
            //Employee.Add("John Smith");
            //Employee.Add("Jackie Jackson");
            //Employee.Add("Chris Jones");
            //Employee.Add("Amanda Cullen");
            //Employee.Add("Jeremy Goodwin");

            Console.WriteLine("There are 5 employees:");
            foreach (string name in Employee)
            {
                Console.WriteLine(name);
            }

            Console.Write("\nEnter an employee name to remove: ");
            if (Employee.Remove(Console.ReadLine()) == false) Console.WriteLine("name does not exist");
            Console.WriteLine();

            foreach (string name in Employee)
            {
                Console.WriteLine(name);
            }

            //string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            //using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "NamesList.txt")))
            //{
            //    foreach (string line in Employee)
            //        outputFile.WriteLine(line);
            //}
        }
    }
}
