﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Password_Strength_Indicator
{
    class Program
    {
        //for jeg fik mit inspration fra.
        //https://social.msdn.microsoft.com/Forums/en-US/5e3f27d2-49af-410a-85a2-3c47e3f77fb1/how-to-check-for-password-strength?forum=csharpgeneral
        static void Main(string[] args)
        {
            string line = string.Empty;
            int result = 0;
            while (result <= 0 )
            {
                Console.Write("Enter password: ");
                line = Console.ReadLine();
                result = PasswordScore(line);
                if (result <= 0) Console.WriteLine("no password try again.");
            }
            if (result == 1) Console.WriteLine("The password '{0}' is a very weak password", line);
            if (result == 2) Console.WriteLine("The password '{0}' is a weak password.", line);
            if (result == 3) Console.WriteLine("The password '{0}' is a strong password.", line);
            if (result == 4) Console.WriteLine("The password '{0}' is a very strong password.", line);
        }
        public static int PasswordScore(string password)
        {
            int score = 0;
            if (password.Length < 1) return score;
            if (password.Length >= 8) score++;
            //score for om der er et tal
            //if (Regex.Match(password, "\b\d") => 1) score++;
            //score for om der er et bogstav
            //if (Regex.)
            //score for at der en speciel tegn
            return score;
        }
    }
}
