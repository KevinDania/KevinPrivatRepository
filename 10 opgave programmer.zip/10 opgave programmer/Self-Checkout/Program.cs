﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Self_Checkout
{
    class Program
    {
        static void Main(string[] args)
        {
            bool d1 = false;
            //bool d2 = false;
            //bool d3 = false;
            Console.Write("Enter the price of item 1: ");
            //skal blive gjort på dem alle så burde have sat det op som en metode så det ikke skulle bliver gjort 3 gange
            //while (d1 == false)
            //{
            //    if (int.TryParse(Console.ReadLine(), out price1)) { d1 = true; }
            //    else { Console.WriteLine("wrong input, takes only numerical value. "); }
            //}
            Console.Write("Enter the price of item 1: ");
            int price1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the quantity of item 1: ");
            int quan1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the price of item 2: ");
            int price2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the quantity of item 2: ");
            int quan2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the price of item 3: ");
            int price3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the quantity of item 3: ");
            int quan3 = Convert.ToInt32(Console.ReadLine());

            int sumprice1 = Calculator(price1, quan1);
            int sumprice2 = Calculator(price2, quan2);
            int sumprice3 = Calculator(price3, quan3);
            double colprice = sumprice1 + sumprice2 + sumprice3;
            double tax = colprice / 100 * 5.5;
            double total = tax + colprice;

            //man kan bruge string.format til at have decimal når der ikke er man jeg fortrækker math.round
            //Console.WriteLine(String.Format("{0:.00}", colprice));
            //Console.WriteLine(String.Format("{0:.00}", tax));
            //Console.WriteLine(String.Format("{0:.00}", total));

            Console.WriteLine("Subtotal: {0}", Math.Round(colprice));
            Console.WriteLine("Tax: {0}", Math.Round(tax, 2));
            Console.WriteLine("Total: {0}", Math.Round(total, 2));
        }

        public static int Calculator(int a, int b)
        {
            int c = a * b;
            return c;
        }
    }
}
