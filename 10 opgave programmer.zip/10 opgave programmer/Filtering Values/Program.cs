﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Filtering_Values
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a list of numbers, separated by spaces: ");
            string num = Console.ReadLine();
            List<string> number = num.Split( ' ' ).ToList();
            Console.Write("The even numbers are ");
            foreach (var item in number)
            {
                if (Convert.ToInt32(item) % 2 == 0)
                {
                    Console.Write("{0} ", item);
                }
            }
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
