﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dertermining_Compound_Interest
{
    class Program
    {
        static void Main(string[] args)
        {

            //hjemmsiden jeg bruger til at lave den rigtig regning stykke: skal få spurgt hvordan "^nt" regnes ind.
            //https://www.calculatorsoup.com/calculators/financial/compound-interest-calculator.php

            Console.Write("What is the principal amount? ");
            int P = Convert.ToInt32(Console.ReadLine());
            Console.Write("What is the rate? (%) ");
            double r = Convert.ToDouble(Console.ReadLine());
            Console.Write("What is the number of years? ");
            double t = Convert.ToInt32(Console.ReadLine());
            Console.Write("What is the number of times the interest is compounded per year ? ");
            double n = Convert.ToInt32(Console.ReadLine());
            double investresult = P * Math.Pow((1 + (r / 100) / n), (n * t));

            //Console.WriteLine(String.Format("{0:.000}", rp));
            Console.WriteLine(Math.Round(investresult, 2));
            Console.WriteLine("${0} invested at {1}% for {2} years compounded {3} times per year is ${4}.", P, r, t, n, Math.Round(investresult, 2));
            Console.ReadLine();
        }
    }
}
