﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retirement_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("What is your current age?: ");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.Write("At what age would you like to retire?: ");
            int reAge = Convert.ToInt32(Console.ReadLine());
            int comAge = reAge - age;
            if (comAge <= 0) { Console.WriteLine("You can retire now"); Environment.Exit(0); }
            Console.WriteLine("You have {0} years left until you can retire.", comAge);
            int currYear = yearTime();
            int reYear = comAge + currYear;
            Console.WriteLine("It's {0}, so you can retire in {1}.", currYear, reYear);
            Console.ReadLine();
        }

        private static int yearTime()
        {
            DateTime date = DateTime.Now;
            string year = date.ToString("yyyy");
            int k = Convert.ToInt32(year);
            return k;
        }
    }
}
