﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Grabbing_the_Weather
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Where are you? ");
            Getweahter("London");
            Console.ReadLine();
        }

        public static void Getweahter(string City)
        {
            WebClient client = new WebClient();
            string url = string.Format("https://api.openweathermap.org/data/2.5/find?q={0}&units=metric&appid=60e6a924b40fff2d5a494e94889d7fb8", City);
            string downloadedString = client.DownloadString(url);
            //Regex rx = new Regex((?=\btemp":).*);
            Console.WriteLine(downloadedString);
        }
    }
}
